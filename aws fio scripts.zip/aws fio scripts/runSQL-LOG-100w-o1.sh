#! /bin/bash
# Usage: runSQL-*.sh [filesize] [toggle-don't-delete-fio-files]

scriptNameWithExt=${0##*/}
scriptName=${scriptNameWithExt%.sh}

if [[ -v _SQLSTORAGE_LOG_DRIVE ]]; then
    dataDir=$_SQLSTORAGE_LOG_DRIVE
else
    dataDir=/home/ubuntu/log-script
fi

dataDir=/home/ubuntu/log-script

resultFiles=seq-write100
numThreads=4
ioDepth=1
blockSize=64k
fileSize=100g
if [ $1 ]; then
        fileSize=$1
fi
if [ -z $2 ]; then
        rm -f $dataDir/$resultFiles*
fi

echo "Running seq write $blockSize $ioDepth IO $fileSize file $numThreads threads"
result=$(fio --name=$resultFiles --ioengine=psync --iodepth=$ioDepth --rw=write --bs=$blockSize --direct=1 --size=$fileSize --numjobs=$numThreads --group_reporting=1 --eta=never --time_based --runtime=60 --directory=$dataDir | tee $scriptName.out | grep IOPS)
#agg=$(echo $result|cut -d',' -f2)
#speed="${agg/aggrb=/Write Speed:}"
#echo $speed
echo $result
echo ""

if [ -z $2 ]; then
        rm -f $dataDir/$resultFiles*
fi
