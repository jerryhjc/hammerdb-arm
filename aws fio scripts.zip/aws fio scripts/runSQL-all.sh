./runSQL-DATA-60r-40w-o32.sh 1g no
sleep 10
./runSQL-LOG-100w-o1.sh 1g no
sleep 10
./runSQL-DATA-70r-30w-o32.sh 1g no
sleep 10
./runSQL-DATA-100r-o32.sh 1g no
sleep 10
./runSQL-DATA-100w-o32.sh 1g no
