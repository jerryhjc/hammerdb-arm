#! /bin/bash
# Usage: runSQL-*.sh [filesize] [toggle-don't-delete-fio-files]

scriptNameWithExt=${0##*/}
scriptName=${scriptNameWithExt%.sh}

if [[ -v _SQLSTORAGE_DATA_DRIVE ]]; then
    dataDir=$_SQLSTORAGE_DATA_DRIVE
else
     dataDir=/home/ubuntu/data-script
fi

dataDir=/home/ubuntu/data-script

resultFiles=random-read60-write40
numThreads=8
ioDepth=32
blockSize=8k
fileSize=10g
if [ $1 ]; then
        fileSize=$1
fi
if [ -z $2 ]; then
        rm -f $dataDir/$resultFiles*
fi

echo "$scriptName: Running random read/write 60/40 $blockSize $ioDepth IO $fileSize file $numThreads threads"
fio --name=$resultFiles --ioengine=psync --iodepth=$ioDepth --rw=randrw --bs=$blockSize --direct=1 --size=$fileSize --rwmixread=60 --rwmixwrite=40 --numjobs=$numThreads --group_reporting=1 --eta=never --time_based --runtime=60 --directory=$dataDir > $scriptName.out
readresult=$(grep 'read: IOPS' $scriptName.out)
writeresult=$(grep 'write: IOPS' $scriptName.out)
#readagg=$(echo $readresult|cut -d',' -f2)
#writeagg=$(echo $writeresult|cut -d',' -f2)
#readspeed="${readagg/aggrb=/Read Speed:}"
#echo $readspeed
echo $readresult
#writespeed="${writeagg/aggrb=/Write Speed:}"
#echo $writespeed
echo $writeresult
echo ""

if [ -z $2 ]; then
        rm -f $dataDir/$resultFiles*
fi

